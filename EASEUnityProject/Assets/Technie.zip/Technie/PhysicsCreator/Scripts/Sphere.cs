using UnityEngine;

namespace Technie.PhysicsCreator
{
	public class Sphere
	{
		public Vector3 center;
		public float radius = 1.0f;
	}
}