
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace Technie.PhysicsCreator
{
	// This is just used as a marker so we can find the asset with our collision meshes in
	public class HullData : ScriptableObject
	{

	}
}